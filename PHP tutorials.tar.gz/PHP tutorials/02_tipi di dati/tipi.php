<?php

/* 
Esistono diversi tipi di variabili:

Si usa il tipo "string" se utilizziamo lettere alfabetiche (ad esempio per salvare un nome);
Si usa il tipo "int" se utilizziamo numeri interi; 
Si usa il tipo "float" se usiamo numeri con la virgola;
Si usa il "boolean" se dobbiamo scegliere su una risposta TRUE o FALSE(vero o falso);
Si usa un array per creare un'insieme di numeri o stringhe, si crea aggiungendo i valori all'interno 
di 2 parentesi graffe, il primo valore dell'indice e' sempre lo zero di default;
Una variabile inizializzata ma non dichiarata quindi senza valore dara' valore NULL;

In php le variabili non sono legate al tipo di valore dichiarato all'inizio, da
stringa si puo' passare ad intero e viceversa

$nome = "Luca";   puo' assumere il valore  di $nome = 1212312; non ha molto senso il nome della variabile 
legata ad un numero ma si puo' fare;






Per scoprire di che tipo e' una variabile si puo' utilizzare il comando "var_dump";
Come utilizzarlo?

Basta stampare la variabile in questo modo:

var_dump($nome_variabile);