<?php

// creiamo 2 variabili, iniziamo a stampare $lorem che poi concateneremo con la variabile $nome;

$lorem = "Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur";
$nome ="Luca";

// echo $lorem;    Stampera' $lorem;

// Per concatenare le 2 variabili aggiungeremo un . tra loro.
//per creare uno spazio tra le 2 stampate oltre al punto serve stampare uno spazio (,' ',)
// Scriveremo quindi:

echo "Il testo della variabile è: " . $lorem . '.' .'<br>' . "La seconda variabile è: " . $nome. '.' .'<br>'."La lunghezza della stringa è: " . strlen($lorem).'.';

// Vuoi customizzare il risultato della stringa $lorem?  usa il comando:

// se vuoi sapere da quanti caratteri è composta la stringa
//(61 nel nostro caso, ricorda il primo valore(detto anche indice) è pari zero).

// echo strlen($lorem);


// Se nella stringa ci sono delle maiuscole ma tu vuoi stamparle tutte in minuscolo si usa:

// echo strTolower($lorem);

// Se invece vuoi che tutto sia stampato in maiuscolo devi usare:

// echo strToUpper($lorem);


// Se vuoi stampare una stringa senza spazi vuoti a caso (ideale in un form, gli utenti spesso
// li lasciano quando inseriscono i propri dati nelle caselle..) usa:

    // echo trim($lorem);
    
    
//  Quante parole ha la nostra stringa? usa:

// echo str_word_count($lorem);

// Vuoi scriverla al contrario?

// echo strrev($lorem);


// vuoi sapere la posizione in cui inizia una parola della stringa?
// il comando e' Key SENSITIVE, devi rispettare le maiuscole.
// se scrivi la parola CIAO devi scriverla tutta in maiuscolo altrimenti non funzionera'.

// echo strpos($lorem.'INSERISCI LA PAROLA TRA QUESTI APICI');


// Come prendere una parte di stringa? Usa:

// echo substr($lorem.12 [<= parola da cui partiamo]); stampera' tutte le lettere che vengono dopo.
// echo substr($lorem.12.5) <= stampera' solo 5 lettere a partire dalla 12sima.

// Per sostituire una parola in una stringa si usa str_replace seguito da:
// vecchia parola, nuova parola, la variabile a cui sostituire la parola;
// RISPETTARE LE MINUOSCOLE MAIUSCOLE per la vecchia parola!

// echo str_replace('porro','Renato',$lorem);








?>