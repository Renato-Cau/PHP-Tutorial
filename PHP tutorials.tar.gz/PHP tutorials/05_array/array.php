<?php

$citta1 = array('Torino','Milano','Bologna');

$citta2 = ['Torino','Milano','Bologna'];

$citta = ['Torino','Milano','Bologna'];

sort($citta);

print_r($citta);

rsort($citta);

print_r($citta);

$persone = [

    //CHIAVE   => VALORE
     "nome"    => "Luca",
     "cognome" => "Bobba",
     "eta"     => "13"

 ];


 $persone = [

    //CHIAVE   => VALORE
        10     => "Luca",
        20     => "Bobba",
        100    => "13"

 ];


 $classi = [
    ["Luca","Paolo","Gianni"],
    ["Othman","Bader","Renato"]
];

/*
for($classe = 0; $classe<count($classi);$classe++){
    echo "CLASSE:". $classe . '<br>';
    for($alunno = 0; $alunno < count($classi[$classe]);$alunno++){
        echo $classi[$classe][$alunno] . '<br>';
    }
};
*/

//echo $classi[0][1];



 /*
 foreach($persone as $chiave => $valore){
    echo $chiave . ' ' . '=>' . ' ' . $valore . '<br>';
}
*/

 //echo $persone[100];     



//$citta[2] = 'Napoli';
//echo $citta[2];

/*
for($i = 0; $i<count($citta2); $i++){
    echo $citta2[$i].' ';
}
*/
/*



ARRAY:


Un array e' una collezione di elementi inseriti in uno spazio di memoria;
Esistono diversi tipi di array: array semplici, array associativi e array multidimensionali.



ARRAY SEMPLICI:

Come dichiarare un array in php?

$citta' = array('Torino','Milano','Bologna');

Oppure in versione ridotta (PIU' USATA):

$citta' = ['Torino','Milano','Bologna'];


ATTENZIONE!! IN UN ARRAY SI INIZIA A CONTARE DA ZERO NON DA UNO, QUINDI IN UN ARRAY DI
3 ELEMENTI SI AVRANNO INDICE 0,1,2.


COME STAMPIAMO UN ARRAY?

Per stampare un elemento dell'array bisogna inserire tra parentesi quadre il numero dell'indice 
che desideriamo a video:

$citta = ['Torino','Milano','Bologna'];

echo $citta[0]; stampera' il primo valore dell'array (IL PRIMO VALORE E' SEMPRE LO ZERO!), TORINO.


COME MODIFICARE UN ELEMENTO DI UN ARRAY?

Basta richiamare l'indice dell'elemento e riassegnarne il valore.

$citta[2] = 'Napoli';

da ora in poi l'array $citta sara':

['Torino',Milano','Napoli']


COME STAMPARE TUTTI GLI ELEMENTI DI UN ARRAY?

Per stamapre un array completo bisogna utilizzare il ciclo for in questo modo:

    for($i = 0; $i<count($citta2); $i++){           <= prende ogni indice dell'array e lo stampa 
                                                       aggiungendo uno spazio usando .' '
    echo $citta2[$i].' ';
    
    }  



    ARRAY ASSOCIATIVI:

    Gli array associativi, rispetto a quelli semplici, non utilizzano l'indice ma
    si creano usando la correlazione "chiave/valore".

    $persone = [

       //CHIAVE   => VALORE
        "nome"    => "Luca",
        "cognome" => "Bobba",
        "eta"     => "13"

    ];

    Per richiamare i valori in questo caso non possiamo piu' usare gli indici ma dobbiamo
    richiamarli usando la chiave.

    echo $persone["nome"];   <= a video stamperemo "Luca"
    echo persona[0];  <=  restituisce errore perche' non trovera' l'indice

    la chiave puo' essere anche numerica:

      $persone = [

       //CHIAVE   => VALORE
           10     => "Luca",
           20     => "Bobba",
           100    => "13"

    ];

    Se eseguo:

    echo $persone[100];     <= stampera' 13


STAMPARE TUTTO L'ARRAY? COME LO STAMPO?

In questo caso va usato il ciclo forEach.

 foreach($persone as $chiave => $valore){
    echo $chiave . ' '. '=>' . ' ' . $valore . '<br>';
}

Come risultato otterremo tutto il contenuto dell'array:

10 => Luca
20 => Bobba
100 => 13




ARRAY MULTIDIMENSIONALI:

Gli array multidimensionali sono array che contengono altri array.

Creiamone uno bidimensionale di array semplici di aule scolastiche:


$classi [
    ['Luca','Paolo','Gianni'],         <= ogni riga rappersenta una classe della scuola;
    ['Othman','Bader','Renato']           ogni riga e' un indice, quindi la prima sara'
];                                        l'indice zero e cosi' via...



COME RICHIAMO PAOLO?

Per richiamare Paolo devo entrare nell'indice zero e richiamare il valore 1 dell'array
( SI INIZIA SEMPRE A CONTARE DA ZERO; NON DIMENTICHIAMOCELO).

Scriveremo quindi:

echo $classi[0][1];


COME STAMPO TUTTO L'ARRAY?

Usiamo un ciclo for con al suo interno un altro for:



for($classe = 0; $classe<count($classi);$classe++){
    echo "CLASSE:". $classe . '<br>';
    for($alunno = 0; $alunno < count($classi[$classe]);$alunno++){
        echo $classi[$classe][$alunno] . '<br>';
    }
};



ORDINARE UN ARRAY:

Per ordinare in ordine crescente o decrescente usiamo sort() ed rsort(), il primo stampa
in ordine crescente mentre il secondo in ordine decrescente;

ESEMPIO:
Creiamo il nostro array:

$citta = ['Torino','Milano','Bologna'];

USIAMO SORT E RSORT:

sort($citta); 

print_r($citta);    stampa in ordine alfabetico o crescente.
                    
quindi otterremo: 
Array ( [0] => Bologna [1] => Milano [2] => Torino ) 



se uso: 

rsort($citta);

print_r($citta);  stavolta stampa in ordine decrescente o non in alfabetico;

Otterremo:
Array ( [0] => Torino [1] => Milano [2] => Bologna ) 


PS: (print_r si usa per vedere al volo tutto il contenuto di un array);


E PER GLI ARRAY ASSOCIATIVI?



TO BE CONTINUED.......




 */


?>