<?php

$operatore_1 = 5;
$operatore_2 = 10.20;
$operatore_3 = '10';

$risultato = $operatore_1 + $operatore_2;

echo $risultato ;

$operatore_1++;
$operatore_1++;

 echo $operatore_1;


/*

Per verificare il contenuto delle nostre stringhe possiamo usare le seguenti condizioni in var_dump:
Tutti questi var_dump restituiranno un boolean come risultato (TRUE o FALSE);

    is_int = per verificare se nella variabile e' presente un intero;
    is_float = per verificare se nella nostra variabile e' presente un numero con la virgola;
    is_string = per verificare se nella nostra stringa e' presente una parola o una frase (STRINGA);


// var_dump(is_int($operatore_1));        
// var_dump(is_float($operatore_2));
// var_dump(is_string($operatore_1));


OPERAZIONI TRA VARIABILI:

echo $operatore_1 + $operatore_2 = 10 + 10.20 = 20.20
echo $operatore_1/$operatore_2 + $operatore_3 = PHP in questo caso convertira'(CAST) il valore stringa '13' 
di $operatore_3 in int ( LO FARA? ANCHE SE METTO LA STRINGA PRIMA!!) ed eseguira':

$operatore_1 + $operatore_3 = 10 + 10 = 20;
$operatore_2 + $operatore_3 = 10.20 + 10 = 20.20; 

Se oltre a '10' ci fossero altri valori non farebbe piu' il cast ma visualizzerebbe un errore! 

COME FARE IL CAST DI UN VALORE:

Per far si che una stringa venga trasformata in un altro tipo basta aggiungere il tipo tra 
parentesi tonde prima del valore:

Esempio:

$operatore_3 = '10';  <= questa variabile ora e' di tipo string;
$operatore_3 = (int)'10'; <= aggiungendo int ora viene vista come int!


NUMERO ASSOLUTO: 

Per trasformare un numero negativo in positivo si usa 'abs' scrivendolo in questo modo:

    $operatore_1 = -10;

var_dump(abs($operatore_1));  prende il -10 e lo trasforma in 10.

TROVARE NUMERO PIU' PICCOLO O PIU' GRANDE:

echo (0,1,2,3,4,5,6);

per trovare il maggiore scriviamo: echo max(1,2,3,4,5,6);
per trovare il minore scriviamo: echo min(1,2,3,4,5,6);

RADICE QUADRATA:

Si usa 'sqrt' in questo modo:

echo sqrt(25); stampera' la radice quadrata di 25, quindi 5.

ARROTONDAMENTO PER DIFETTO O ECCESSO:

Si usa 'round' in questo modo:

echo round(0.49); essendo meno della meta' stampera' per difetto, quindi 0;
echo round(0.50); dalla meta' esatta in poi stampera' per eccesso, quindi 1;

STAMPARE UN NUMERO RANDOM:

Si usa 'rand' in questo modo:

echo rand(0,100);  rand necessita' di un range quindi bisogna impostargli
il numero da cui partire ed il numero in cui finire.

SOMMA, SOTTRAZIONE, MOLTIPLCAZIONE, DIVISIONE, POTENZA, RESTO:

echo $operatore_1 + $operatore_2;
echo $operatore_1 - $operatore_2;
echo $operatore_1 * $operatore_2;
echo $operatore_1 / $operatore_2;
echo $operatore_1 ** $operatore_1;
echo $operatore_1 % $operatore_2;


RIASSEGNARE VALORE AD UNA VARIABILE;

$operatore_1 = 5;
Per cambiare il valore bisogna scrivere:

$operatore_1 += 5;  stampera' 10..perche'? Perche' mettendo il + davanti all'uguale
        
 $operatore_1 = 5   prende il vecchio valore di $operatore_1
 $operatore_1 += 5  con il + davanti  fa 5 + 5 = 10

 Si puo' anche sottrarre un valore a quello originale, basta usare il - al posto del +

 $operatore_1 -= 3; prende il valore iniziale di $operatore_1 e gli sottrae 3;

 Stesso discorso vale per moltiplicazione e divisione, basta usare * e / al posto di + e -.

 INCREMENTO E DECREMENTO:

 usare ++ o -- per incrementare o diminuire il valore di una variabile:

 $operatore_1 = 5 ;
 $operatore_1++ ;

 echo $operatore_1; stampera' il vecchio valore + 1, quindi 6.













*/

?>