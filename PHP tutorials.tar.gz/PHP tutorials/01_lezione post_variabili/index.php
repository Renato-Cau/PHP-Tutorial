<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        form{
            display: flex;
            flex-direction: column;
            width: 200px;
            padding: 40px;
        }
        
        input{
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <h1>Form esempio</h1>
    <form method="POST" action="esempio.php">
        <label for="nome">nome</label>
        <input type="text" name="nome" placeholder="Inserisci nome">
        <input type="text" name="cognome" placeholder="Inserisci cognome">
        <label for="cognome">cognome</label>
        <input type="submit" value="Invia dati">
    </form>
</body>
</html>