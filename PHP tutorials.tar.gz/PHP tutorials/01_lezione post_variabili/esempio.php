<?php

$nome = $_POST['nome'];

$cognome = $_POST['cognome'];

echo "Ciao " . $nome . ' ' . $cognome . "!";

echo " Benvenuto nel nostro server. "; 

?>