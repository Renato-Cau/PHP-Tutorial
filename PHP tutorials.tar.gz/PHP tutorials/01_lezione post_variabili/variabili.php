<?php   // oltre all'estensione .php per iniziare un progetto si deve utilizzare il tag <?php 
        // all'inizio di ogni file. 
        



// le variabili in php si dichiarano utilizzando il simbolo del 
// dollaro '$' prima del nome della variabile stessa:

$nome = $_POST['nome'];

// a video si stampano utilizzando il comando 'ECHO' scritto prima della variabile:
echo $nome;


// per chiuderlo si usa il tag '?>'; 
?>  